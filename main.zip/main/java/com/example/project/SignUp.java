package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.JsonReader;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.util.ArrayList;

public class SignUp extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                TextView username= (TextView) findViewById(R.id.username);
                TextView email= (TextView) findViewById(R.id.email);
                TextView password= (TextView) findViewById(R.id.password);

                SharedPreferences sharedPreferences = getSharedPreferences("users",MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sharedPreferences.edit();

                String oldUsersList = sharedPreferences.getString("users", "");
                JSONStringer jt = new JSONStringer();
                JSONObject jo = new JSONObject();
                JSONArray ja = new JSONArray();




                if (oldUsersList == "") {
                    List<String> usersList = new ArrayList<String>();
                    usersList.add(username.toString() + ":" + password.toString());

                    // convert list to JSON
                    String asJson = ja.toString(usersList);

                    myEdit.putString("users", asJSON);
                    myEdit.commit();
                } else {
                    List<String> usersList = new ArrayList<String>();
                    Type type = new TypeToken<List<String>>() {}.getType();
                    usersList = gson.fromJson(oldUsersList, type);
                    usersList.add(username.toString() + ":" + password.toString());

                    String asJson = gson.toJson(usersList);
                    myEdit.putString("users", asJSON);
                    myEdit.commit();

            }
        });

        Button SignUpbtn = (Button) findViewById(R.id.SignUpbtn);
        SignUpbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity2();
            }
        });
    }

    // back to home button
    public void Activity1() {
        Intent intent = new Intent(this, welcome.class);
        startActivity(intent);
    }
    public void Activity2() {

        Intent intent = new Intent(this, home.class);
        startActivity(intent);
    }
}