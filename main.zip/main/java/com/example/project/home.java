package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.security.cert.PKIXRevocationChecker;

public class home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        TextView username;


        username= (TextView) findViewById(R.id.username);
        SharedPreferences sp= PreferenceManager.getDefaultSharedPreferences(home.this);
        String email=sp.getString("email" , "Not Found");
        username.setText(email);


        ImageButton musicbtn1 = (ImageButton) findViewById(R.id.musicbtn1);
        musicbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, Music.class);
                startActivity(intent);
            }
        });

        ImageButton musicbtn2 = (ImageButton) findViewById(R.id.musicbtn2);
        musicbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, music1.class);
                startActivity(intent);
            }
        });

        ImageButton musicbtn3 = (ImageButton) findViewById(R.id.musicbtn3);
        musicbtn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, music2.class);
                startActivity(intent);
            }
        });

        ImageButton musicbtn4 = (ImageButton) findViewById(R.id.musicbtn4);
        musicbtn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, music3.class);
                startActivity(intent);
            }
        });
        ImageButton PREV = (ImageButton) findViewById(R.id.PREV);
        PREV.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, welcome.class);
                startActivity(intent);
            }
        });

    }
    }