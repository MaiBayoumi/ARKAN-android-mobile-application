package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        TextView username = (TextView) findViewById(R.id.username);
        TextView password = (TextView) findViewById(R.id.password);

        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity1();
            }
        });

        Button loginbtn = (Button) findViewById(R.id.loginbtn);
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(login.this);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("email", username.getText().toString());
                editor.apply();
                {Activity2();}

            }
        });
    }



    public void Activity1() {
        //String name = Username.getText().toString();
        // String emailad = email.getText().toString();
        //String pass = password.getText().toString();
        //SharedPreferences.Editor editor= sharedPreferences.edit() ;
        //put data in shared preferences
        //editor.putString("name",name);
        //editor.putString("email",emailad);
        //editor.putString("password",pass);
        //apply changes to shared preferences
        //editor.apply();
        Intent intent = new Intent(this, welcome.class);
        startActivity(intent);
    }
// back to home button
    public void Activity2() {
        Intent intent = new Intent(this, home.class);
        startActivity(intent);
    }
}


